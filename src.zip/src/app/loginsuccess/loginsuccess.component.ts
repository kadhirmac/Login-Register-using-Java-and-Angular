import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-loginsuccess',
  templateUrl: './loginsuccess.component.html',
  styleUrls: ['./loginsuccess.component.css']
})
export class LoginsuccessComponent implements OnInit {


  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  logout(){
    Swal.fire({
      title:'Are you sure?',
      text:'',
      icon:'warning',
      showCancelButton:true,
      confirmButtonText:'YES',
      cancelButtonText:'Cancel'
    }).then((result)=>{
      if(result.value){
        this.router.navigate(['/']);
      }
    })
  }
}
