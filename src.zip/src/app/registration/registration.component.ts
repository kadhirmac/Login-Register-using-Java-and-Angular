

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  //POJO 
  //Objects
 user =new User();
  msg=''; // initially blank when it getting response it return given msg

  constructor(private _service : RegistrationService,private _router:Router) { }

  ngOnInit(): void {
  }
  registerUser(){
    //method to calling service
    //Use that Observable response to Subcribe it
    this._service.registerUserFromRemote(this.user).subscribe(
      data =>{ // then it ll return data
        console.log("response received");
        this._router.navigate(['/login'])
      },//else throws exception 
      error =>{
        console.log("exception occured");
        this.msg=error.error;

      
      }
    )
  }

}
