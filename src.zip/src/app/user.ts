//POJO class in angular
export class User {
    id:number;
    emailId:string;
    username:string;
    password:string;
    constructor(){}
        
        }

