package com.app.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.app.login.model.User;
import com.app.login.service.LoginService;

@RestController
public class LoginController {
	
	@Autowired
	private LoginService service;
	
	//Post method to mapp this method 
	@PostMapping("/registeruser") //mapping path url
	@CrossOrigin(origins="http://localhost:4200") // to enable cors policy to access
	public User registerUser(@RequestBody User user)throws Exception { // request body from user class(format which i given)
		String tempEmailId= user.getEmailId(); // temp variable to get the user details
		if(tempEmailId != null && !"".equals(tempEmailId)) {
		User userobj=service.fetchUserByEmailId(tempEmailId);//calling the method from service  
		if(userobj!=null) { // checks email already exists for registration
			throw new Exception("user with "+tempEmailId+" is already exist");// if there , It'll throw msg
	}
		} // else save the details
		User userObj = null;
		userObj =service.saveUser(user);
		return userObj;
	}
	
	//Post method to mapp this method
	@PostMapping("/login") //mapping path
	@CrossOrigin(origins="http://localhost:4200") // to enable cors policy to access
	public User loginUser(@RequestBody User user) throws Exception {
		String tempEmailId = user.getEmailId();
		String tempPass= user.getPassword();
		User userObj =null; //Initially null
		if(tempEmailId !=null && tempPass != null) {
			//call method from service to check condition of password
			userObj= service.fetchUserByEmailIdAndPassword(tempEmailId, tempPass);
		}
		//if user details not registered then show error msg
		if(userObj ==null) {
			throw new Exception("Bad Credentials");
		} //if there return details
		return  userObj;
	}
}
	
	









